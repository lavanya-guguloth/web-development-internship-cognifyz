document.getElementById("colorButton").addEventListener("click", function() {
  this.style.backgroundColor = this.style.backgroundColor === 'green' ? 'blue' : 'green';
});

function showGreeting() {
  const hour = new Date().getHours();
  let greeting;
  if (hour < 12) greeting = "Good morning!";
  else if (hour < 18) greeting = "Good afternoon!";
  else greeting = "Good evening!";
  alert(greeting);
}

function addNumbers() {
  const num1 = parseFloat(document.getElementById("num1").value);
  const num2 = parseFloat(document.getElementById("num2").value);
  const result = num1 + num2;
  document.getElementById("result").innerText = "Result: " + result;
}
